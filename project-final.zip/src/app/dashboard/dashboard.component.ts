import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CardDataService } from '../card-data.service';
import { Idetails } from '../card-data';
import { FormGroup , FormBuilder} from '@angular/forms';

import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public detail:Idetails[]=[];
  public details:Idetails[]=[];
  searchTerm: string='';
  searchKey:string ="";
  constructor(private _carddetails:CardDataService, private router:Router) { }

  ngOnInit() {
    this._carddetails.getdetail()
    .subscribe(data => this.detail = data,);

  // this._carddetails.getdetail().forEach(element => {
  //   this.details=element;
  // });
  }
  search(event: any){
    this.searchTerm = (event.target as HTMLInputElement).value;
    console.log(this.searchTerm);
    this.searchKey=this.searchTerm;
   // this._carddetails.getdetail().search.next(this.searchTerm);
  }
 
  onSelect(datas: Idetails){
    this.router.navigate(['/details',datas.id]);
  }
}
