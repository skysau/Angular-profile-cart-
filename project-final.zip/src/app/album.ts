export interface Ialbum {
    id: string,
    userId: string,
    title:  string,
  
}